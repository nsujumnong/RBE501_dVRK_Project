da Vinci MTM CAD model from WPI
Created by Allen Zhang
Time received: 2013-06-06

