
psm_rviz.launch:
    used to visulize psm in rviz
    
psm_exp.launch: don't know
psm_stable.launch: from WPI don't know

mtm_right_rviz.launch: only one MTMR simulation  
mtm_psm_rviz.launch: one MTMR + one PSM1 simulation  
