### dvrk_pcl package

**What is required**  
* uvc_camera
* camera_info_url
* pcdViewer(in dvrk_pcl/src)
* stereo_image_proc
* image_view

**Note**
This package has been tested in Ubuntu 12.04 with ROS Hydro Catkin. 

