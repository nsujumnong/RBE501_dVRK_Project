dvrk_joint_publisher
==========
This package converts raw joint position and velocity values to JointStates with
name, position and velocity properly populated.

# File 
* scripts/mtm\_joint\_publisher.py
* todo: psm version or maybe just modify mtm version
